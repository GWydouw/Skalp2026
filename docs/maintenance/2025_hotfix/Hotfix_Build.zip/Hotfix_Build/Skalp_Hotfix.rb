require "sketchup"
require "extensions"

module SkalpHotfix2025
  # MARK: - EMERGENCY PATCH
  # This code runs immediately on load to intercept the Skalp expiration date check.

  # 1. Secure a reference to the original Time.new method
  unless Time.respond_to?(:skalp_hotfix_original_new)
    class << Time
      alias skalp_hotfix_original_new new
    end
  end

  # 2. Monkey-patch Time.new
  class << Time
    def new(*args)
      # Target strict signature: Time.new(2025, 12, 31)
      if args.size >= 3 && args[0] == 2025 && args[1] == 12 && args[2] == 31

        # Safety: Only apply if 'Skalp' is in the caller path
        target_caller = caller.find { |c| c =~ /Skalp/i }

        if target_caller
          # puts ">>> [Skalp Hotfix] Intercepted Expiration Date in #{target_caller}"
          # Return a date in the future (2099)
          return skalp_hotfix_original_new(2099, 12, 31)
        end
      end

      # Pass-through for all other calls
      skalp_hotfix_original_new(*args)
    end
  end

  # MARK: - EXTENSION REGISTRATION
  # Allows management via Extension Manager

  ext = SketchupExtension.new("Skalp Hotfix", "Skalp_Hotfix/main")
  ext.description = "Emergency patch for Skalp expiration issue. Please keep this enabled."
  ext.version = "1.0.0"
  ext.creator = "Skalp"
  ext.copyright = "2025 Skalp"

  Sketchup.register_extension(ext, true)
end
