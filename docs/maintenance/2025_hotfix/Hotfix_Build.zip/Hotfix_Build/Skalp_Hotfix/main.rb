module SkalpHotfix2025
  # The critical logic is already loaded by the root file (Skalp_Hotfix.rb)
  # This file exists to satisfy the SketchupExtension loading requirement and
  # to confirm the extension is 'enabled'.

  def self.active?
    true
  end
end
